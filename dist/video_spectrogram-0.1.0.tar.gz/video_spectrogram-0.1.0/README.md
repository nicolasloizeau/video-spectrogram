


# Generate video spectrograms from audio files

## Install from github


```bash
pip install git+https://github.com/nicolasloizeau/video-spectrogram.git#egg=video-spectrogram
```

## Usage

Help
```bash
video-spectrogram --help
```
Example
```bash
video-spectrogram audio.mp3 --maxfreq 2000 --fps 30
```
